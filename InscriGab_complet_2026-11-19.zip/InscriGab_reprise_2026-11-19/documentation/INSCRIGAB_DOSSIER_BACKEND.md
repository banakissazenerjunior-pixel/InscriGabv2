# INSCRIGAB — Dossier technique du backend Supabase

> Document établi à partir d'une inspection en lecture du projet Supabase InscriGab.
> Il décrit l'état observé au moment de l'inspection. Ce document n'est pas un dump SQL restaurable.

## 1. Architecture observée

- Base de données : PostgreSQL via Supabase.
- Authentification : Supabase Auth (`auth.users`).
- API métier : fonctions PostgreSQL exposées en RPC.
- Traitement serveur : Supabase Edge Functions.
- Fichiers : Supabase Storage.
- Contrôle d'accès : Row Level Security (RLS).
- Les parents accèdent à leur dossier avec un lien personnel ; ils ne créent pas de compte parent.

## 2. Tables recensées

### Schéma `public` (16 tables)

| Table | Rôle observé |
|---|---|
| `ecoles` | Établissements, configuration, frais, statut et coordonnées de paiement |
| `classes` | Classes et capacités d'accueil |
| `parents` | Identité, téléphone et lien personnel |
| `eleves` | Identité et informations des élèves |
| `inscriptions` | Dossiers d'inscription et statut |
| `documents` | Métadonnées des pièces fournies |
| `paiements` | Paiements liés aux inscriptions |
| `utilisateurs` | Comptes des personnels et rôles |
| `abonnements` | Formules et périodes d'abonnement des établissements |
| `sauvegardes` | Références de sauvegardes |
| `demandes_restauration` | Demandes de restauration |
| `permissions_ecole` | Permissions par rôle et établissement |
| `permissions_ecole_historique` | Historique des changements de permissions |
| `cas_speciaux` | Situations particulières concernant une inscription |
| `ecoles_statuts_historique` | Historique des statuts des établissements |
| `paiements_abonnements` | Paiements des abonnements |

### Schéma `private` (4 tables)

| Table | Rôle observé |
|---|---|
| `paiements_historique` | Historique des changements de statut des paiements |
| `inscriptions_historique` | Historique des changements de statut des inscriptions |
| `cas_speciaux_historique` | Historique des cas particuliers |
| `limites_inscription` | Clés de limitation des inscriptions |

Les 20 tables recensées ont RLS activé au moment de l'inspection.

## 3. Relations principales

- `parents` 1—N `eleves` via `eleves.parent_id`.
- `eleves` 1—N `inscriptions` via `inscriptions.eleve_id`.
- `ecoles` 1—N `classes`, `inscriptions`, `utilisateurs`, `abonnements`, `paiements_abonnements`.
- `classes` 1—N `inscriptions` via `inscriptions.classe_id`.
- `inscriptions` 1—N `documents`.
- `inscriptions` 1—1 `paiements` (la colonne `paiements.inscription_id` est unique).
- `ecoles` 1—N `permissions_ecole`, `cas_speciaux`, `sauvegardes` et historiques associés.
- `abonnements` 1—N `paiements_abonnements`.
- `utilisateurs.id` référence `auth.users.id`.

## 4. Fonctions PostgreSQL/RPC recensées

### Schéma `public`

- `ajouter_document(p_lien text, p_inscription integer, p_type text, p_chemin text, p_nom text)`
- `classes_ecole()`
- `creer_ecole(p_nom text, p_type text, p_ville text, p_nom_directeur text, p_telephone text, p_numero_autorisation text, p_niveaux text[], p_max_par_classe integer, p_frais_inscription integer, p_frais_dossier integer, p_montant_mensuel integer, p_docs text[], p_classes jsonb)`
- `decider_ecole(p_ecole integer, p_validation text)`
- `decider_inscription(p_inscription integer, p_decision text, p_commentaire text)`
- `declarer_cas_special(p_inscription_id integer, p_type_cas text, p_description text)`
- `dossiers_ecole()`
- `enregistrer_classe(p_id integer, p_nom text, p_places integer, p_frais integer)`
- `enregistrer_paiement(p_lien text, p_dossier uuid, p_methode text, p_telephone text, p_nom_compte text, p_code text)`
- `finaliser_inscription_ecole()`
- `lister_cas_speciaux(p_inscription_id integer, p_statut text)`
- `lister_classes(p_ecole integer)`
- `lister_ecoles_ouvertes()`
- `lister_permissions_ecole()`
- `ma_abonnement()`
- `ma_session()`
- `modifier_ecole(p_donnees jsonb)`
- `modifier_permission_ecole(p_role text, p_permission text, p_autorise boolean)`
- `mon_dossier(p_lien text)`
- `sa_abonnements()`
- `sa_demandes_restauration()`
- `sa_ecole(p_id integer)`
- `sa_ecoles()`
- `sa_exporter_ecole(p_ecole integer)`
- `sa_modifier_statut_ecole(p_ecole integer, p_statut text, p_motif text)`
- `sa_paiements_abonnements()`
- `sa_sauvegardes()`
- `sa_tableau_de_bord()`
- `sa_traiter_demande_restauration(p_id uuid, p_decision text)`
- `sa_utilisateurs()`
- `soumettre_inscription(p_ecole integer, p_parent_nom text, p_parent_tel text, p_annee text, p_enfants jsonb)`
- `supprimer_classe(p_id integer)`
- `traiter_cas_special(p_cas_special_id bigint, p_decision text, p_commentaire text)`
- `valider_paiement(p_paiement integer, p_decision text, p_commentaire text)`

### Schéma `private`

- `dossier_existe(p text)`
- `dossier_ok(p text)`
- `eleve_ok(p_id integer)`
- `est_super_admin()`
- `exiger_super_admin()`
- `inscription_ok(p_id integer)`
- `mon_ecole()`
- `mon_role()`
- `normaliser_numero_gabon(p text)`
- `operateur_du_numero(p text)`
- `parent_ok(p_id integer)`
- `semer_permissions(p_ecole integer)`
- `trg_semer_permissions()`
- `utilisateur_a_permission(p_permission text)`
- `verifier_paiement_avant_validation_inscription()`

Les fonctions marquées `SECURITY DEFINER` doivent être auditées avec attention : leurs droits effectifs dépendent de leur code, de leur propriétaire et de leurs contrôles internes.

## 5. Sécurité RLS observée

Les politiques recensées comprennent notamment :

- `ecoles_select` : accès limité au super-administrateur ou à l'établissement de l'utilisateur.
- `ecoles_update` : mise à jour limitée au directeur de son établissement.
- `classes_all` : accès limité au super-administrateur ou à l'établissement courant.
- `inscriptions_select` et `inscriptions_update` : accès limité à l'établissement courant, avec exception super-administrateur en lecture.
- `eleves_select` : contrôle par `private.eleve_ok(...)` ou super-administrateur.
- `parents_select` : contrôle par `private.parent_ok(...)` ou super-administrateur.
- `documents_select` et `paiements_select` : contrôle par inscription autorisée ou super-administrateur.
- `permissions_ecole` et `sauvegardes` : règles spécifiques à l'établissement et au super-administrateur.

Ce résumé n'est pas un remplacement de l'export complet des politiques SQL. Il faut vérifier les politiques exactes avant toute modification.

## 6. Edge Function active

### `parent-document-upload`

- État observé : ACTIVE.
- Version observée : 2.
- Vérification JWT au niveau de la fonction : désactivée (`verify_jwt = false`).
- Le code réalise ses propres contrôles au moyen du lien personnel parent et de l'appartenance de l'inscription à ce parent.
- Méthodes HTTP : `POST` et `OPTIONS`.
- Types document acceptés : `acte_naissance`, `photo`, `carnet_sante`, `bulletin`, `piece_parent`.
- Formats acceptés : PDF, JPEG, PNG, WebP.
- Taille maximale : 5 Mo.
- Bucket utilisé : `documents`, privé.
- Parcours : génération d'une URL d'upload signée, dépôt du fichier, vérification de sa présence puis appel RPC `ajouter_document`.

Le code source complet actuellement déployé est conservé dans le fichier `edge-functions/parent-document-upload/index.ts` du dossier d'export associé, s'il est fourni avec ce document.

## 7. Stockage

Bucket recensé :

| Bucket | Public | Taille maximale | Types MIME |
|---|---:|---:|---|
| `documents` | Non | 5 Mo | PDF, JPEG, PNG, WebP |

## 8. Points de vigilance à auditer

1. Vérifier que chaque fonction `SECURITY DEFINER` contrôle explicitement l'identité et les autorisations attendues.
2. Examiner la fonction Edge `parent-document-upload` : `verify_jwt` est désactivé, donc les contrôles applicatifs du lien parent sont essentiels.
3. Vérifier les limites de durée, de révocation et de partage des liens personnels parents.
4. Vérifier le parcours complet des paiements et les confirmations réelles des opérateurs Mobile Money. Une ligne enregistrée en base ne prouve pas à elle seule qu'un opérateur a confirmé le paiement.
5. Vérifier les sauvegardes et tester une restauration.
6. Vérifier le raccordement du frontend à Supabase et repérer les éventuelles données encore conservées uniquement dans `localStorage`.
7. Exporter les migrations, triggers, index, vues, fonctions et politiques dans un véritable dépôt versionné.

## 9. Limites de ce document

Ce dossier est un inventaire technique construit à partir des métadonnées et fonctions visibles lors de l'inspection. Il ne contient pas :
- un dump SQL intégral restaurable ;
- toutes les définitions SQL des fonctions et triggers ;
- les données des élèves, parents ou établissements ;
- les clés API, secrets ou mots de passe ;
- le code source du frontend.

Ne jamais publier de clé `service_role`, de secret Supabase ou de données personnelles dans un dépôt GitHub public.

## 10. Prochaine étape recommandée

Créer un export de schéma contrôlé et non destructif depuis Supabase, récupérer les migrations et versions des Edge Functions, puis les placer dans un dépôt Git privé. Faire une sauvegarde avant toute opération de modification.
