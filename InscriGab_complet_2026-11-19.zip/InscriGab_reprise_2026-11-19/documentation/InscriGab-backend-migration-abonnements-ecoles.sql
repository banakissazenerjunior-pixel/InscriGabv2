-- InscriGab : abonnements Airtel Money / Moov Money + désactivation/archivage réversible
-- Cette migration prépare les données et les RPC. Les encaissements réels attendent
-- le contrat marchand, les clés API et le format de webhook du prestataire choisi.

-- 1) Statut opérationnel d'une école (distinct de la validation administrative).
alter table public.ecoles
  add column if not exists statut_plateforme text not null default 'active',
  add column if not exists statut_modifie_le timestamptz,
  add column if not exists statut_modifie_par uuid references auth.users(id),
  add column if not exists motif_statut text;

do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conname = 'ecoles_statut_plateforme_check'
      and conrelid = 'public.ecoles'::regclass
  ) then
    alter table public.ecoles
      add constraint ecoles_statut_plateforme_check
      check (statut_plateforme in ('active', 'desactive', 'archivee'));
  end if;
end $$;

create table if not exists public.ecoles_statuts_historique (
  id bigint generated always as identity primary key,
  ecole_id integer not null references public.ecoles(id) on delete restrict,
  ancien_statut text not null check (ancien_statut in ('active', 'desactive', 'archivee')),
  nouveau_statut text not null check (nouveau_statut in ('active', 'desactive', 'archivee')),
  motif text,
  modifie_par uuid references auth.users(id),
  modifie_le timestamptz not null default now()
);
alter table public.ecoles_statuts_historique enable row level security;
revoke all on table public.ecoles_statuts_historique from anon, authenticated;

-- 2) Historique des encaissements d'abonnements InscriGab.
create table if not exists public.paiements_abonnements (
  id uuid primary key default gen_random_uuid(),
  ecole_id integer not null references public.ecoles(id) on delete restrict,
  abonnement_id uuid not null references public.abonnements(id) on delete restrict,
  reference_interne text not null unique default ('IGSUB-' || upper(replace(gen_random_uuid()::text, '-', ''))),
  reference_prestataire text unique,
  montant numeric(12,2) not null check (montant > 0),
  devise text not null default 'XAF' check (devise = 'XAF'),
  methode text not null check (methode in ('airtel_money', 'moov_money')),
  telephone_paiement text,
  statut text not null default 'initialise'
    check (statut in ('initialise', 'en_attente', 'paye', 'echec', 'annule', 'rembourse')),
  initie_le timestamptz not null default now(),
  paye_le timestamptz,
  metadata jsonb not null default '{}'::jsonb check (jsonb_typeof(metadata) = 'object'),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists paiements_abonnements_ecole_created_idx
  on public.paiements_abonnements(ecole_id, created_at desc);
create index if not exists paiements_abonnements_statut_paye_idx
  on public.paiements_abonnements(paye_le desc) where statut = 'paye';
alter table public.paiements_abonnements enable row level security;
revoke all on table public.paiements_abonnements from anon, authenticated;

-- 3) Les comptes d'une école désactivée/archivée ne conservent aucun accès opérationnel.
create or replace function private.mon_ecole()
returns integer
language sql
stable
security definer
set search_path to ''
as $function$
  select u.ecole_id
  from public.utilisateurs u
  join public.ecoles e on e.id = u.ecole_id
  where u.id = (select auth.uid())
    and u.role in ('directeur', 'secretaire')
    and e.statut_plateforme = 'active'
$function$;

create or replace function private.utilisateur_a_permission(p_permission text)
returns boolean
language plpgsql
stable
security definer
set search_path to ''
as $function$
declare
  v_role text;
  v_ecole_id integer;
  v_autorise boolean;
begin
  if (select auth.uid()) is null then return false; end if;

  select u.role, u.ecole_id into v_role, v_ecole_id
  from public.utilisateurs u where u.id = (select auth.uid());
  if not found then return false; end if;
  if v_role = 'super_admin' then return true; end if;
  if v_role not in ('directeur', 'secretaire') or v_ecole_id is null then return false; end if;
  if not exists (
    select 1 from public.ecoles e
    where e.id = v_ecole_id and e.statut_plateforme = 'active'
  ) then return false; end if;

  select p.autorise into v_autorise
  from public.permissions_ecole p
  where p.ecole_id = v_ecole_id
    and p.role = v_role
    and p.permission = p_permission;
  return coalesce(v_autorise, false);
end;
$function$;

create or replace function public.ma_session()
returns jsonb
language plpgsql
stable
security definer
set search_path to ''
as $function$
declare
  v_uid uuid := (select auth.uid());
  u record;
  v_ecole jsonb := null;
  v_perms jsonb;
  v_statut_plateforme text;
begin
  if v_uid is null then raise exception 'non_connecte'; end if;
  select id, ecole_id, nom, prenom, email, role into u
  from public.utilisateurs where id = v_uid;
  if not found then return jsonb_build_object('role', null); end if;

  if u.ecole_id is not null then
    select e.statut_plateforme into v_statut_plateforme
    from public.ecoles e where e.id = u.ecole_id;
    if v_statut_plateforme = 'desactive' then raise exception 'ecole_desactivee'; end if;
    if v_statut_plateforme = 'archivee' then raise exception 'ecole_archivee'; end if;
  end if;

  select coalesce(jsonb_agg(perm.nom order by perm.nom), '[]'::jsonb) into v_perms
  from unnest(array['consulter_inscriptions','gerer_inscriptions','declarer_cas_special','traiter_cas_special','consulter_paiements','valider_paiements','gerer_classes','gerer_documents','consulter_historique']) as perm(nom)
  where private.utilisateur_a_permission(perm.nom);

  if u.ecole_id is not null then
    select jsonb_build_object(
      'id', e.id, 'nom', e.nom, 'type', e.type, 'ville', e.ville,
      'validation', e.validation, 'statut_plateforme', e.statut_plateforme,
      'session_ouverte', e.session_ouverte, 'nom_directeur', e.nom_directeur,
      'telephone_directeur', e.telephone_directeur, 'numero_autorisation', e.numero_autorisation,
      'niveaux', e.niveaux, 'max_par_classe', e.max_par_classe,
      'frais_inscription', e.frais_inscription, 'frais_dossier', e.frais_dossier,
      'montant_mensuel', e.montant_mensuel, 'docs_demandes', e.docs_demandes,
      'numero_airtel_money', e.numero_airtel_money, 'numero_moov_money', e.numero_moov_money,
      'numero_orange_money', e.numero_orange_money, 'date_limite_paiement', e.date_limite_paiement
    ) into v_ecole from public.ecoles e where e.id = u.ecole_id;
  end if;

  return jsonb_build_object(
    'id', u.id, 'role', u.role, 'nom', u.nom, 'prenom', u.prenom,
    'email', u.email, 'permissions', v_perms, 'ecole', v_ecole
  );
end
$function$;

-- 4) Fonctions Super Admin : état d'une école, historique et action réversible.
create or replace function public.sa_modifier_statut_ecole(
  p_ecole integer,
  p_statut text,
  p_motif text default null
)
returns void
language plpgsql
security definer
set search_path to ''
as $function$
declare
  v_ancien text;
  v_uid uuid := (select auth.uid());
begin
  perform private.exiger_super_admin();
  if p_ecole is null or p_ecole <= 0 then raise exception 'ecole_invalide'; end if;
  if p_statut is null or p_statut not in ('active', 'desactive', 'archivee') then raise exception 'statut_ecole_invalide'; end if;
  if p_motif is not null and length(btrim(p_motif)) > 500 then raise exception 'motif_trop_long'; end if;

  select statut_plateforme into v_ancien
  from public.ecoles where id = p_ecole for update;
  if not found then raise exception 'ecole_introuvable'; end if;
  if v_ancien = p_statut then return; end if;

  update public.ecoles
  set statut_plateforme = p_statut,
      statut_modifie_le = now(),
      statut_modifie_par = v_uid,
      motif_statut = nullif(btrim(coalesce(p_motif, '')), '')
  where id = p_ecole;

  insert into public.ecoles_statuts_historique(
    ecole_id, ancien_statut, nouveau_statut, motif, modifie_par
  ) values (
    p_ecole, v_ancien, p_statut,
    nullif(btrim(coalesce(p_motif, '')), ''), v_uid
  );
end;
$function$;
revoke all on function public.sa_modifier_statut_ecole(integer, text, text) from public, anon;
grant execute on function public.sa_modifier_statut_ecole(integer, text, text) to authenticated;

create or replace function public.sa_ecoles()
returns jsonb
language plpgsql
stable
security definer
set search_path to ''
as $function$
begin
  perform private.exiger_super_admin();
  return coalesce((
    select jsonb_agg(jsonb_build_object(
      'id', e.id, 'nom', e.nom, 'ville', e.ville, 'type', e.type,
      'numero_autorisation', e.numero_autorisation, 'validation', e.validation,
      'statut_plateforme', e.statut_plateforme, 'statut_modifie_le', e.statut_modifie_le,
      'motif_statut', e.motif_statut, 'session_ouverte', e.session_ouverte,
      'nom_directeur', e.nom_directeur, 'created_at', e.created_at,
      'nb_eleves', (select count(*) from public.inscriptions i where i.ecole_id = e.id and i.statut <> 'refuse'),
      'plan', (select a.plan from public.abonnements a where a.ecole_id = e.id order by a.created_at desc limit 1)
    ) order by e.created_at desc, e.id desc)
    from public.ecoles e
  ), '[]'::jsonb);
end
$function$;

create or replace function public.sa_ecole(p_id integer)
returns jsonb
language plpgsql
stable
security definer
set search_path to ''
as $function$
declare v jsonb;
begin
  perform private.exiger_super_admin();
  select jsonb_build_object(
    'id', e.id, 'nom', e.nom, 'type', e.type, 'ville', e.ville,
    'validation', e.validation, 'statut_plateforme', e.statut_plateforme,
    'statut_modifie_le', e.statut_modifie_le, 'motif_statut', e.motif_statut,
    'session_ouverte', e.session_ouverte, 'created_at', e.created_at,
    'nom_directeur', e.nom_directeur, 'telephone_directeur', e.telephone_directeur,
    'numero_autorisation', e.numero_autorisation, 'niveaux', e.niveaux,
    'frais_inscription', e.frais_inscription, 'frais_dossier', e.frais_dossier,
    'montant_mensuel', e.montant_mensuel,
    'numero_airtel_money', e.numero_airtel_money, 'numero_moov_money', e.numero_moov_money,
    'nb_classes', (select count(*) from public.classes c where c.ecole_id = e.id),
    'nb_eleves', (select count(*) from public.inscriptions i where i.ecole_id = e.id and i.statut <> 'refuse'),
    'nb_en_attente', (select count(*) from public.inscriptions i where i.ecole_id = e.id and i.statut = 'en_attente'),
    'nb_valides', (select count(*) from public.inscriptions i where i.ecole_id = e.id and i.statut = 'valide'),
    'encaisse', coalesce((select sum(p.montant) from public.paiements p join public.inscriptions i on i.id = p.inscription_id where i.ecole_id = e.id and p.statut_paiement = 'paye'), 0),
    'cas_speciaux_ouverts', (select count(*) from public.cas_speciaux cs where cs.ecole_id = e.id and cs.statut in ('en_attente','en_cours')),
    'plan', (select a.plan from public.abonnements a where a.ecole_id = e.id order by a.date_debut desc limit 1),
    'utilisateurs', coalesce((select jsonb_agg(jsonb_build_object('nom', u.nom, 'prenom', u.prenom, 'email', u.email, 'role', u.role)) from public.utilisateurs u where u.ecole_id = e.id), '[]'::jsonb),
    'historique_statuts', coalesce((select jsonb_agg(jsonb_build_object('ancien_statut', h.ancien_statut, 'nouveau_statut', h.nouveau_statut, 'motif', h.motif, 'modifie_le', h.modifie_le) order by h.modifie_le desc) from public.ecoles_statuts_historique h where h.ecole_id = e.id), '[]'::jsonb)
  ) into v from public.ecoles e where e.id = p_id;
  if v is null then raise exception 'ecole_introuvable'; end if;
  return v;
end
$function$;

-- 5) RPCs de consultation des abonnements et paiements.
create or replace function public.ma_abonnement()
returns jsonb
language plpgsql
stable
security definer
set search_path to ''
as $function$
declare
  v_ecole integer;
  v_abonnement jsonb;
  v_paiements jsonb;
  v_nom text;
begin
  if (select auth.uid()) is null then raise exception 'non_connecte'; end if;
  if private.mon_role() <> 'directeur' then raise exception 'reserve_directeur'; end if;
  v_ecole := private.mon_ecole();
  if v_ecole is null then raise exception 'ecole_introuvable'; end if;

  select nom into v_nom from public.ecoles where id = v_ecole;
  select jsonb_build_object(
    'id', a.id, 'plan', a.plan, 'montant', a.montant,
    'date_debut', a.date_debut, 'date_fin', a.date_fin, 'statut', a.statut
  ) into v_abonnement
  from public.abonnements a
  where a.ecole_id = v_ecole
  order by a.date_debut desc, a.created_at desc
  limit 1;

  select coalesce(jsonb_agg(jsonb_build_object(
    'reference', p.reference_interne, 'montant', p.montant, 'devise', p.devise,
    'methode', p.methode, 'statut', p.statut, 'initie_le', p.initie_le, 'paye_le', p.paye_le
  ) order by p.created_at desc), '[]'::jsonb)
  into v_paiements
  from public.paiements_abonnements p where p.ecole_id = v_ecole;

  return jsonb_build_object(
    'ecole', v_nom,
    'abonnement', v_abonnement,
    'paiements', v_paiements,
    'moyens_paiement', jsonb_build_array('airtel_money', 'moov_money'),
    'paiement_en_ligne_actif', false
  );
end
$function$;
revoke all on function public.ma_abonnement() from public, anon;
grant execute on function public.ma_abonnement() to authenticated;

create or replace function public.sa_paiements_abonnements()
returns jsonb
language plpgsql
stable
security definer
set search_path to ''
as $function$
begin
  perform private.exiger_super_admin();
  return coalesce((
    select jsonb_agg(jsonb_build_object(
      'id', p.id, 'ecole_id', p.ecole_id, 'ecole', e.nom,
      'reference', p.reference_interne, 'reference_prestataire', p.reference_prestataire,
      'montant', p.montant, 'devise', p.devise, 'methode', p.methode,
      'statut', p.statut, 'initie_le', p.initie_le, 'paye_le', p.paye_le
    ) order by p.created_at desc)
    from public.paiements_abonnements p join public.ecoles e on e.id = p.ecole_id
  ), '[]'::jsonb);
end
$function$;
revoke all on function public.sa_paiements_abonnements() from public, anon;
grant execute on function public.sa_paiements_abonnements() to authenticated;

create or replace function public.sa_abonnements()
returns jsonb
language plpgsql
stable
security definer
set search_path to ''
as $function$
begin
  perform private.exiger_super_admin();
  return coalesce((
    select jsonb_agg(jsonb_build_object(
      'id', a.id, 'ecole_id', a.ecole_id, 'ecole', e.nom,
      'plan', a.plan, 'statut', a.statut, 'montant', a.montant,
      'date_debut', a.date_debut, 'date_fin', a.date_fin,
      'statut_plateforme', e.statut_plateforme
    ) order by a.date_debut desc)
    from public.abonnements a join public.ecoles e on e.id = a.ecole_id
  ), '[]'::jsonb);
end
$function$;

-- 6) Le tableau Super Admin mesure désormais les abonnements InscriGab payés,
-- et non les frais d'inscription des élèves qui reviennent aux établissements.
create or replace function public.sa_tableau_de_bord()
returns jsonb
language plpgsql
stable
security definer
set search_path to ''
as $function$
begin
  perform private.exiger_super_admin();
  return jsonb_build_object(
    'ecoles_total', (select count(*) from public.ecoles),
    'ecoles_a_verifier', (select count(*) from public.ecoles where validation = 'a_verifier'),
    'ecoles_validees', (select count(*) from public.ecoles where validation in ('auto','valide')),
    'ecoles_refusees', (select count(*) from public.ecoles where validation = 'refuse'),
    'eleves_total', (select count(*) from public.inscriptions where statut <> 'refuse'),
    'eleves_ce_mois', (select count(*) from public.inscriptions where statut <> 'refuse' and date_inscription >= date_trunc('month', current_date)::date),
    'cas_speciaux_ouverts', (select count(*) from public.cas_speciaux where statut in ('en_attente','en_cours')),
    'demandes_restauration', (select count(*) from public.demandes_restauration where statut = 'en_attente'),
    'utilisateurs_total', (select count(*) from public.utilisateurs),
    'chiffre_affaires_mois', coalesce((
      select sum(p.montant)::bigint
      from public.paiements_abonnements p
      where p.statut = 'paye'
        and p.paye_le >= (date_trunc('month', now() at time zone 'Africa/Libreville') at time zone 'Africa/Libreville')
        and p.paye_le < ((date_trunc('month', now() at time zone 'Africa/Libreville') + interval '1 month') at time zone 'Africa/Libreville')
    ), 0)
  );
end
$function$;

-- 7) Une école désactivée ou archivée n'apparaît plus dans le parcours public d'inscription.
create or replace function public.lister_ecoles_ouvertes()
returns table(id integer, nom text, type text, ville text, niveaux text[], frais_inscription integer, frais_dossier integer, docs_demandes text[])
language sql
stable
security definer
set search_path to ''
as $function$
  select e.id, e.nom, e.type, e.ville, e.niveaux, e.frais_inscription, e.frais_dossier, e.docs_demandes
  from public.ecoles e
  where e.session_ouverte and e.validation <> 'refuse' and e.statut_plateforme = 'active'
  order by e.nom
$function$;

create or replace function public.lister_classes(p_ecole integer)
returns table(id integer, nom_classe text, places_restantes integer, frais_inscription integer)
language sql
stable
security definer
set search_path to ''
as $function$
  select c.id, c.nom_classe,
    greatest(c.places_max - (select count(*)::int from public.inscriptions i where i.classe_id = c.id and i.statut <> 'refuse'), 0),
    coalesce(c.frais_inscription, e.frais_inscription)
  from public.classes c
  join public.ecoles e on e.id = c.ecole_id
  where c.ecole_id = p_ecole
    and e.session_ouverte
    and e.validation <> 'refuse'
    and e.statut_plateforme = 'active'
  order by c.nom_classe
$function$;

-- Renforce aussi le contrôle au moment de soumettre un nouveau dossier.
create or replace function public.soumettre_inscription(
  p_ecole integer, p_parent_nom text, p_parent_tel text, p_annee text, p_enfants jsonb
)
returns jsonb
language plpgsql
security definer
set search_path to ''
as $function$
declare
  v_parent integer; v_lien text; v_dossier uuid := gen_random_uuid(); e jsonb; v_eleve integer; v_classe record; v_n integer;
  v_ip text; v_tel text; v_naissance date; v_sexe text;
begin
  if not exists (
    select 1 from public.ecoles
    where id = p_ecole and session_ouverte and validation <> 'refuse'
      and statut_plateforme = 'active'
  ) then raise exception 'ecole_fermee'; end if;
  if length(trim(coalesce(p_parent_nom,''))) < 2 or length(regexp_replace(coalesce(p_parent_tel,''), chr(92) || 's', '', 'g')) < 8 then raise exception 'parent_invalide'; end if;
  if jsonb_typeof(p_enfants) <> 'array' then raise exception 'enfants_invalides'; end if;
  v_n := jsonb_array_length(p_enfants);
  if v_n < 1 or v_n > 10 then raise exception 'nombre_enfants_invalide'; end if;

  v_tel := regexp_replace(p_parent_tel, '[^0-9]', '', 'g');
  v_ip := coalesce(nullif(trim(split_part(coalesce((nullif(current_setting('request.headers', true), '')::jsonb) ->> 'x-forwarded-for', ''), ',', 1)), ''), 'inconnue');
  delete from private.limites_inscription where cree_le < now() - interval '1 day';
  if (select count(*) from private.limites_inscription where cle = 'tel:' || v_tel and cree_le > now() - interval '1 hour') >= 5
     or (select count(*) from private.limites_inscription where cle = 'ip:' || v_ip and cree_le > now() - interval '1 hour') >= 20 then
    raise exception 'trop_de_demandes';
  end if;
  insert into private.limites_inscription(cle) values ('tel:' || v_tel), ('ip:' || v_ip);

  insert into public.parents(nom, telephone)
  values (left(trim(p_parent_nom),100), left(trim(p_parent_tel),30))
  returning id, lien_perso into v_parent, v_lien;

  for e in select value from jsonb_array_elements(p_enfants) loop
    if length(trim(coalesce(e->>'nom',''))) < 1 or length(trim(coalesce(e->>'prenom',''))) < 1 then raise exception 'enfant_invalide'; end if;
    begin v_naissance := nullif(e->>'date_naissance','')::date; exception when others then raise exception 'date_naissance_invalide'; end;
    if v_naissance is null or v_naissance > current_date - interval '1 year' or v_naissance < current_date - interval '30 years' then raise exception 'date_naissance_invalide'; end if;
    v_sexe := case when e->>'sexe' in ('Fille','Garçon') then e->>'sexe' else null end;
    select c.id, c.places_max into v_classe from public.classes c
    where c.id = (e->>'classe_id')::integer and c.ecole_id = p_ecole for update;
    if not found then raise exception 'classe_invalide'; end if;
    if (select count(*) from public.inscriptions i where i.classe_id = v_classe.id and i.statut <> 'refuse') >= v_classe.places_max then raise exception 'classe_pleine'; end if;
    insert into public.eleves(parent_id, nom, prenom, date_naissance, sexe)
    values (v_parent, left(trim(e->>'nom'),100), left(trim(e->>'prenom'),100), v_naissance, v_sexe)
    returning id into v_eleve;
    insert into public.inscriptions(eleve_id, ecole_id, classe_id, annee_scolaire, dossier_id)
    values (v_eleve, p_ecole, v_classe.id, left(coalesce(p_annee,'2026-2027'),20), v_dossier);
  end loop;
  return jsonb_build_object('lien_perso', v_lien, 'dossier_id', v_dossier);
end
$function$;

-- Droits explicites des nouvelles RPC publiques.
revoke all on function public.sa_ecoles() from public, anon;
grant execute on function public.sa_ecoles() to authenticated;
revoke all on function public.sa_ecole(integer) from public, anon;
grant execute on function public.sa_ecole(integer) to authenticated;
revoke all on function public.ma_session() from public, anon;
grant execute on function public.ma_session() to authenticated;
revoke all on function public.sa_abonnements() from public, anon;
grant execute on function public.sa_abonnements() to authenticated;
revoke all on function public.sa_tableau_de_bord() from public, anon;
grant execute on function public.sa_tableau_de_bord() to authenticated;
revoke all on function public.lister_ecoles_ouvertes() from public, authenticated;
grant execute on function public.lister_ecoles_ouvertes() to anon, authenticated;
revoke all on function public.lister_classes(integer) from public, authenticated;
grant execute on function public.lister_classes(integer) to anon, authenticated;
revoke all on function public.soumettre_inscription(integer, text, text, text, jsonb) from public, authenticated;
grant execute on function public.soumettre_inscription(integer, text, text, text, jsonb) to anon;


-- 8) Les fonctions de gestion des permissions doivent aussi refuser les écoles suspendues.
create or replace function public.lister_permissions_ecole()
returns table(role text, permission text, autorise boolean)
language plpgsql stable security definer set search_path to ''
as $function$
declare v_ecole_id integer; v_role text;
begin
  select u.ecole_id, u.role into v_ecole_id, v_role
  from public.utilisateurs u where u.id = (select auth.uid());
  if v_ecole_id is null or v_role <> 'directeur' then raise exception 'reserve_directeur'; end if;
  if private.mon_ecole() is distinct from v_ecole_id then raise exception 'ecole_introuvable'; end if;
  return query
  select roles.role, perms.permission, coalesce(cfg.autorise, false)
  from (values ('directeur'::text), ('secretaire'::text)) as roles(role)
  cross join (values
    ('consulter_inscriptions'::text), ('gerer_inscriptions'::text), ('declarer_cas_special'::text),
    ('traiter_cas_special'::text), ('consulter_paiements'::text), ('valider_paiements'::text),
    ('gerer_classes'::text), ('gerer_documents'::text), ('consulter_historique'::text)
  ) as perms(permission)
  left join public.permissions_ecole cfg on cfg.ecole_id = v_ecole_id and cfg.role = roles.role and cfg.permission = perms.permission
  order by roles.role, perms.permission;
end;
$function$;

create or replace function public.modifier_permission_ecole(p_role text, p_permission text, p_autorise boolean)
returns void language plpgsql security definer set search_path to ''
as $function$
declare v_uid uuid := (select auth.uid()); v_ecole_id integer; v_role_actuel text; v_ancienne_valeur boolean;
begin
  if v_uid is null then raise exception 'non_connecte'; end if;
  select u.ecole_id, u.role into v_ecole_id, v_role_actuel from public.utilisateurs u where u.id = v_uid;
  if v_role_actuel <> 'directeur' or v_ecole_id is null then raise exception 'reserve_directeur'; end if;
  if private.mon_ecole() is distinct from v_ecole_id then raise exception 'ecole_introuvable'; end if;
  if p_role not in ('directeur','secretaire') then raise exception 'role_invalide'; end if;
  if p_permission not in ('consulter_inscriptions','gerer_inscriptions','declarer_cas_special','traiter_cas_special','consulter_paiements','valider_paiements','gerer_classes','gerer_documents','consulter_historique') then raise exception 'permission_invalide'; end if;
  if p_autorise is null then raise exception 'valeur_permission_invalide'; end if;
  select p.autorise into v_ancienne_valeur from public.permissions_ecole p
  where p.ecole_id = v_ecole_id and p.role = p_role and p.permission = p_permission for update;
  insert into public.permissions_ecole(ecole_id,role,permission,autorise,modifie_par,modifie_le)
  values(v_ecole_id,p_role,p_permission,p_autorise,v_uid,now())
  on conflict(ecole_id,role,permission) do update set autorise=excluded.autorise,modifie_par=excluded.modifie_par,modifie_le=excluded.modifie_le;
  if v_ancienne_valeur is distinct from p_autorise then
    insert into public.permissions_ecole_historique(ecole_id,role,permission,ancienne_valeur,nouvelle_valeur,modifie_par)
    values(v_ecole_id,p_role,p_permission,v_ancienne_valeur,p_autorise,v_uid);
  end if;
end;
$function$;

-- Les accès directs aux tables restent fermés; ces politiques sont une protection supplémentaire.
do $$
begin
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='ecoles_statuts_historique' and policyname='ecoles_statuts_historique_super_admin_select') then
    create policy ecoles_statuts_historique_super_admin_select on public.ecoles_statuts_historique
      for select to authenticated using ((select private.est_super_admin()));
  end if;
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='paiements_abonnements' and policyname='paiements_abonnements_super_admin_select') then
    create policy paiements_abonnements_super_admin_select on public.paiements_abonnements
      for select to authenticated using ((select private.est_super_admin()));
  end if;
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='paiements_abonnements' and policyname='paiements_abonnements_ecole_directeur_select') then
    create policy paiements_abonnements_ecole_directeur_select on public.paiements_abonnements
      for select to authenticated using (ecole_id = (select private.mon_ecole()) and (select private.mon_role()) = 'directeur');
  end if;
end $$;
